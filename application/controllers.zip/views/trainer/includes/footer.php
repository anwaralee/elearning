</div><!--wrapper--> 

<div class="footer">
eLearning - Copyright © Vital One Technologies
</div>


</body>
</html>