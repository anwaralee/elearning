</div><!--wrapper-->

<div class="footer">
Training Management System - Copyright © Web Nepal
</div>


</body>
</html>