<h2>Success</h2>
<div class="seperator"></div>
<p>You’ve successfully registered to Training Management system. Please login to continue. 
    
    <a href="<?php echo base_url();?>login/">Login here</a>

Thank you!
</p>